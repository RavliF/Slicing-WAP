<!DOCTYPE html>
<html lang="en">

<head>
    <?php include('head.php') ?>
</head>

<body>
    <?php include('navbar.php') ?>
    <?php include('header.php') ?>
    <?php include('content.php') ?>
    <?php include('footer.php') ?>
</body>

</html>